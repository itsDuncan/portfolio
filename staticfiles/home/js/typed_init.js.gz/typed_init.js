$(document).ready(function () {
	var typed = new Typed('#typed', {
		stringsElement: '#typed-strings',
		startDelay: 1000,
		backDelay: 1000,
		typeSpeed: 40,
		backSpeed: 40,
		smartBackspace: true
	});
})